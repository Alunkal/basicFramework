package com.basicFramework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcekDataProvider {

	XSSFWorkbook wb ;
	public ExcekDataProvider() {
		
		File src = new File(".//TestData//testData.xlsx");
		
		try {
			FileInputStream fis = new FileInputStream(src);
			wb= new XSSFWorkbook(fis);
			
		} catch (Exception e) {
			System.out.println(" excel is not readble");
		}
		
	}
	
	public String getStringData(String sheet, int row, int colum) {
		return wb.getSheet("Sheet1").getRow(0).getCell(0).getStringCellValue();
		
	}
	
	public Double getNumericData(String sheet, String row, String colum) {
		return wb.getSheet("").getRow(0).getCell(0).getNumericCellValue();
		
	}

}
