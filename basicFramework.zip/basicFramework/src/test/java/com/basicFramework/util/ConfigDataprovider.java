package com.basicFramework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigDataprovider {
	
	Properties pro;

	public ConfigDataprovider() {
		File src = new File(".//config//config.properties");
		try {
		FileInputStream fis = new FileInputStream(src);
		pro = new Properties();
	
			pro.load(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getDataFromConfig(String key) {
		return  pro.getProperty(key);
		
	}
	
	public String getBrowserFromConfig() {
		return pro.getProperty("Brwoser");
		
	}
	
	public String getURLFromConfig() {
		return pro.getProperty("qaURL");
		
	}

}
