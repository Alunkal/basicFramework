package com.basicFramework.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class LoginPage {
	WebDriver driver ;

	public LoginPage(WebDriver driver) {
		this.driver= driver;
	}
	 
	 @FindBy(xpath = "//div[contains(text(),'Pages')]") WebElement Pages;
	 @FindBy(xpath = "//div[contains(text(),'Login')]") WebElement LoginButton;
	 @FindBy(xpath = "//input[contains(@name,'userid')]") WebElement txtuserid;
	 @FindBy(xpath = "//input[contains(@name,'password')]") WebElement txtpassword;
	 @FindBy(xpath = "//span[contains(text(),'Login')]") WebElement Login;
	 String frame= "examples-iframe";
	 @FindBy(xpath = "//div[contains(text(),'Email')]") WebElement email;
	 @FindBy(xpath = "//div[contains(@class,'x-grid-item-container')]//tbody/tr/td/div[text()='Rhea Clemons']") WebElement singleEmail;
	 @FindBy(xpath = "//div[contains(text(),'Rhea Clemons')]/../../../../..//div[contains(@class,'mail-body')]") WebElement emailContent;
	 

	 

		
//		driver.findElement(By.xpath("//div[contains(@class,'x-grid-item-container')]//tbody/tr/td/div[text()='Rhea Clemons']")).click();
//		String dec= driver.findElement(By.xpath("//div[contains(text(),'Rhea Clemons')]/../../../../..//div[contains(@class,'mail-body')]")).getText();
//		Assert.assertTrue(dec.contains("Eiusmod duis irure\r\n" + 
//				"nostrud elit esse nostrud”"));
	 
/**
 * 
 * @param username
 * @param password
 */
	 public void loginToSenchaDashboard(String username, String password ) {
		 driver.switchTo().frame(frame);
		 Pages.click();
		 LoginButton.click();
		 txtuserid.sendKeys(username);
		 txtpassword.sendKeys(password);
		 Login.click();
		 
	 }
	 
	 /**
	  * 
	  */
	 public void clickEmailAndVerify()
	 {
		 email.isDisplayed();
		 email.click();
	 }
	 
	 /**
	  * 
	  */
	 public boolean OpenEmailAndVerify(String message)
	 {
		 singleEmail.click();
		 String actual = emailContent.getText();		 
		 return actual.contains(message);
	 }
			 
}
