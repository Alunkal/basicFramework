package com.basicFramework.testcase;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.basicFramework.pages.LoginPage;

import junit.framework.Assert;

public class sechaDashboard extends baseTest {

	LoginPage loginPage;
	
	@Test(priority = 0)
	public void verifyALogin() {		
		excel.getStringData("Sheet1", 0, 0);	
		loginPage =PageFactory.initElements(driver, LoginPage.class);
		loginPage.loginToSenchaDashboard(excel.getStringData("Sheet1", 0, 0), excel.getStringData("Sheet1", 0, 1));
	
	}
	
	@Test (priority = 1)
	public void verifyEmailTab() {		
		loginPage.clickEmailAndVerify();
	
	}
	
	@Test (priority = 2)
	public void verifythecontentOfEmail() {			
	Assert.assertTrue(loginPage.OpenEmailAndVerify("Eiusmod duis irure nostrud elit esse nostrud”"));
	}
}
