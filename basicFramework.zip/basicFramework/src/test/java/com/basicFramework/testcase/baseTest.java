package com.basicFramework.testcase;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.basicFramework.util.BrowserFactory;
import com.basicFramework.util.ConfigDataprovider;
import com.basicFramework.util.ExcekDataProvider;
import com.basicFramework.util.Helper;

public class baseTest {

	public WebDriver driver;
	public ExcekDataProvider excel;
	public ConfigDataprovider config;
	
	@BeforeSuite
	public void setSuite() {
		 excel = new ExcekDataProvider();
		 config= new ConfigDataprovider();
	}

	@BeforeClass
	public void setup() {
		driver=	BrowserFactory.initlise(driver, config.getBrowserFromConfig(), config.getURLFromConfig());	
	}
	
	@AfterClass
	public void tearDown() {
		BrowserFactory.quitBrowser(driver);
	}
	
	@AfterMethod
	public void tearDownMethod(ITestResult reult) {
		if(reult.getStatus()==ITestResult.FAILURE) {
			Helper.captureScreenshot(driver);
		}
		
	}

}
