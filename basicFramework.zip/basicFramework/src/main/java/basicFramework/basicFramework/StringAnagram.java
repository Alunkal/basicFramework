package basicFramework.basicFramework;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String args[]) {
	 boolean status = isanagram("keep","peek");
	 if(status) {
		 System.out.println("Anagram");
	 }
	 else {
		 System.out.println("not anagram"
		 		+ "");
	 }
		
	}

	public static boolean isanagram(String string, String string2) {
		boolean status;
		if(string.length()!=string2.length()){
			status= false;
		}
		else {
			char[]array1 = string.toLowerCase().toCharArray();
			char[]array2 = string2.toLowerCase().toCharArray();
			Arrays.sort(array1);
			Arrays.sort(array2);
			status = array1.equals(array1);
		}
		return status;
	}
	
	
	


}
