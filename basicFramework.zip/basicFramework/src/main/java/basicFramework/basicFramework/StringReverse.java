package basicFramework.basicFramework;

public class StringReverse {

	public static void main(String args[]) {
		String given = "India is my country";
		String out="";
		for (int i=given.length()-1;i>=0;i--) {
		out=out+given.charAt(i);
		}
		
		System.out.println(out);
		
		StringBuffer bf= new StringBuffer(given);
		System.out.println(bf.reverse());
		
		
		
		
	}
	


}
